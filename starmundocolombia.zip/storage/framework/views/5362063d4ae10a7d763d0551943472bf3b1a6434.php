<?php
$contactos = App\Redes::where('contacto', 1)->where('redes', null)->get();
?>
<div class="container-fluid"  style="background-color:#0362BC"><div class="container py-4">
<div class="row justify-content-center">


<div class="col-12 col-lg-5 col-md-10 p-3 pl-5 text-white">
<div class="text-center">
<img src="/imagenes/png/logo-starmundo.png" class="w-75 h-auto mt-2 mb-4" />
</div>


<?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div>
		<?php if($contacto->imagen): ?>
			<img src="/imagenes/iconos/<?php echo e($contacto->imagen); ?>" width="20" height="25" class="my-2 mx-4" />
		<?php endif; ?>
		<?php echo e($contacto->descripcion); ?>

	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<div class="col-12 col-lg-7 col-md-12 text-center">
<iframe src="https://www.google.com/maps/d/embed?mid=1HrfYniOA-p2oryDe3R-wia8WPvc61OAv" class="w-100" height="400px"></iframe>
</div>
</div>
</div>
</div>