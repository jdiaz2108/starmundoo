<?php $__env->startSection('title', 'Listar Videos - '); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Listar Videos</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="/admin/">Inicio</a></li>
                            <li class="active">Listar Videos</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Lista de Videos</strong>
                            </div>
                            <div class="card-body">
                                <table id="table_id" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Nombre</th>
                                            <th>Link</th>
                                            <th>Botones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($video->id); ?></td>
                                            <td><?php echo e($video->nombre); ?></td>
                                            <td><?php echo e($video->link); ?></td>
                                            <td>
                                            <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
                                                <div class="btn-group mr-2" role="group" aria-label="First group">
                                                <a href="/admin/videos/<?php echo e($video->id); ?>/edit" class="btn btn-warning input-group-addon">Editar</a>
                                            </div>
                                            <div class="btn-group mr-2" role="group" aria-label="Second group">
                                                <?php echo Form::open(['route' => ['videos.destroy', $video->id], 'method' => 'DELETE' ]); ?>

                                                    <?php echo Form::button('Eliminar', ['class' => 'btn btn-danger input-group-addon' , 'data-toggle' => 'modal' , 'data-target' => '#Modal'.$video->id ]); ?>

                                                    <div class="modal fade" id="Modal<?php echo e($video->id); ?>" tabindex="-1" role="dialog" aria-labelledby="ModalLabell<?php echo e($video->id); ?>" aria-hidden="true">
                                                      <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                          <div class="modal-header">
                                                            <h5 class="modal-title" id="ModalLabell<?php echo e($video->id); ?>">Ventana de Confirmación</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                              <span aria-hidden="true">&times;</span>
                                                            </button>
                                                          </div>
                                                          <div class="modal-body">
                                                            Esta seguro que desea eliminar el Contenido: <?php echo e($video->nombre); ?> ?
                                                          </div>
                                                          <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Volver</button>
                                                            <?php echo Form::submit('Eliminar Contenido', ['class' => 'btn btn-danger']); ?>

                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                <?php echo Form::close(); ?>

                                            </div>
                                        </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {

        $('#table_id').DataTable({
            "pagingType": "full_numbers",
            "order": [[ 0, "desc" ]]
        });
    } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>