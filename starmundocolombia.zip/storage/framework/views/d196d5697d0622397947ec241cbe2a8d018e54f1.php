<?php
$videos = App\Video::all()->sortKeysDesc();
?>

<?php if($videos): ?>
<div class="container-fluid">
	<div class="owl-carousel owl-theme">
	    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <div class="item-video border bg-dark img-fluid">
	        <a class="owl-video img-fluid" href="<?php echo e($video->link); ?>">
	        </a>
	    </div>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php endif; ?>