<!DOCTYPE html>
<html lang="es-ES">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>¡Curso Laravel!</h2>

<div>
   ¡Bienvenido al sitio Web de <?php echo e($view); ?> !
</div>

</body>
</html>