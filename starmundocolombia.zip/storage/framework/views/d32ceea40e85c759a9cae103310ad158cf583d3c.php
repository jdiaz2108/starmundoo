<?php $__env->startSection('title', 'Categorias - '); ?>
<?php $__env->startSection('bc1link', 'mecago'); ?>
<?php $__env->startSection('bc1text', 'mecago1'); ?>

<?php $__env->startSection('bc2text', 'mecago2'); ?>

<?php $__env->startSection('content'); ?>
<?php
$categoria = App\Subcategoria::find($subcategoria->id)->categoria;
$contenidos = App\Subcategoria::find($subcategoria->id)->contenidos;
?>
<?php echo $__env->make('layouts.breadcrumb', ['link2' => $subcategoria, 'link1' => $categoria], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="py-3">
        <div class="container">
            <?php if($contenidos->count() > 0): ?>
            <?php $__currentLoopData = $contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contenido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row m-5 border py-4 bg-white">
                    
                <div class="col-md-6 my-auto">
                    <img class="img-fluid d-block mx-auto"
                    <?php if($contenido->imagen): ?>
                        src="/imagenes/<?php echo e(strtolower(str_replace(' ', '', $categoria->nombre))); ?>/<?php echo e(strtolower(str_replace(' ', '', $subcategoria->nombre))); ?>/<?php echo e($contenido->imagen); ?>"
                    <?php else: ?>
                        src="https://static.pingendo.com/cover-bubble-light.svg"
                    <?php endif; ?>
                ></div>

                <div class="px-md-5 p-3 col-md-6 d-flex flex-column justify-content-center">
                    <h1><?php echo e($contenido->nombre); ?></h1>
                    <p class="my-3 lead"><?php echo nl2br($contenido->descripcion); ?></p>
                </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="row m-5 border py-4">
                    
                <div class="col-md-6">
                    <img class="img-fluid d-block"
                        src="https://static.pingendo.com/cover-bubble-light.svg"
                ></div>

                <div class="px-md-5 p-3 col-md-6 d-flex flex-column justify-content-center">
                    <h1>Cargando</h1>
                    <p class="my-3 lead">Descripcion</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>