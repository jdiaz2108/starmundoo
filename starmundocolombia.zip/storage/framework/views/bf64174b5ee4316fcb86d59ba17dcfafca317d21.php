<div class="container-fluid mb-4 bg-white border shadow-sm">
    <div class="container">
        <div class="d-flex p-4">
          <div class="mr-auto h4 my-auto px-4">
          <a class="breadcrumb-item text-primary" href="/">Inicio</a>
          <?php if($link1 != null): ?>
                <a class="breadcrumb-item text-primary text-capitalize" href="/<?php echo e($link1->slug); ?>" ><?php echo e(strtolower($link1->nombre)); ?></a>
           <?php endif; ?>
           <?php if(is_object($link2)): ?>
                <a class="breadcrumb-item active" aria-current="page"><?php echo e(strtolower($link2->nombre)); ?></a>
            <?php else: ?>
                <a class="breadcrumb-item active" aria-current="page"><?php echo e($link2); ?></a>
            <?php endif; ?>
          </div>
        </div>
    </div>
</div>