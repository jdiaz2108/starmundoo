<footer class="site-footer">
    <div class="footer-inner bg-white">
        <div class="row">
            <div class="col-sm-6">
                Copyright &copy; 2018 StarmundoColombia Admin
            </div>
            <div class="col-sm-6 text-right">
                Desarrollado por <a href="https://colorlib.com">XyberGroup.</a>
            </div>
        </div>
    </div>
</footer>