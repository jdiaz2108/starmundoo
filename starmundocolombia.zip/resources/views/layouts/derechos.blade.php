<div class="container-fluid" style="background-color:#024582">
	<div class="container">
		<div class="row p-4 text-white">
			<div class="col-12 col-lg-8">
				<h6>STARMUNDO - Bogot&aacute; D.C. - Colombia | Todos los Derechos Reservados &copy; 2018</h6>
			</div>

			<div class="col-lg">
			</div>

			<div class="col-12 col-lg-2">
				<h6>Desarrollo: <a href="http://www.xybergroup.co/" target="_blank" class="text-white">XyberGroup </a></h6>
			</div>
		</div>
	</div>
</div>