<div class=" container-fluid bg-white">
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-6 mt-3 mb-3 col-md-5">
            <img src="/imagenes/jpg/logo-starmundocolombia.jpg" class="img-fluid mx-auto" />
        </div>
        <div class="col-lg-4 col-9 col-md-3 my-auto">
            <p class="text-center">Tel: [57-1] 805 3331<br />
            Servicio al Cliente: 315 749 1783
            <br />
            Calle 25F No. 85B-26 - Piso 2<br />
            Barrio Santa Cecilia - Modelia <br />
            Bogot&aacute; - Colombia </p>
        </div>
        <div class="col-lg-2 col-3 vertical-center col-md-1 my-auto">
                <img src="/imagenes/png/ubicarnos.png" class="img-fluid" />
        </div>
    </div>
    </div>
</div>