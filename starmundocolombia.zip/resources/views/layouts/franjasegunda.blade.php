<div class=" container-fluid pt-3 pb-3" style="background-color:#D2D5D3">
<div class="row justify-content-center">





<div class="col-12 col-lg-3 p-4 col-md-7 " >
    <h4 class="text-right text-danger" >Telares Star</h4>
    <p class="text-right text-secondary">Excelentes telares de puntilla y de diferentes dise&ntilde;os y tama&ntilde;os</p>
        <div class="text-right">
        <a href="nav.php?mod=Adornos" class="btn btn-secondary" role="button" aria-pressed="true">Ver Mas</a>
        </div>
</div>

<div class="col-12 col-lg-2 text-center col-md-5">
<img src="/imagenes/jpg/telares-180.jpg" alt="John Doe" class="mt-2 mb-2 text-center" style="width:180px; height:180px">
</div>






<div class="col-12 col-lg-3 p-4 col-md-7 ">
    <h4 class="text-right text-danger" >Carta de Colores</h4>
    <p class="text-right text-secondary">Conozca todos los colores y seleccione la mejor opci&oacute;n</p>
        <div class="text-right">
        <a href="nav.php?mod=Adornos" class="btn btn-secondary" role="button" aria-pressed="true">Ver Mas</a>
        </div>
</div>

<div class="col-12 col-lg-2 text-center col-md-5">
<img src="/imagenes/jpg/carta-de-colores-180.jpg" alt="John Doe" class="mt-2 mb-2 text-center" style="width:180px; height:180px">
</div>
</div>
</div>