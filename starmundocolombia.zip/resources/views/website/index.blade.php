@extends('layouts.base')
@section('content')
@include('layouts.slider')
@include ('layouts.categorias')
@endsection