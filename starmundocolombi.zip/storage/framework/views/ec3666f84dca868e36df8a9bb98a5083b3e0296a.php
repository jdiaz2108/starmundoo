<?php
$categorias = App\Categoria::all();
?>
<nav class="navbar navbar-expand-md sticky-top navbar-dark"  style="background-color:#0362BC">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
        <ul class="navbar-nav">
        <li class="nav-item">
        <a class="nav-link text-light ml-3 mr-3" href="../index.php">Inicio</a>
        </li>
<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$subcategorias = App\Categoria::find($categoria->id)->subcategorias;
?>


        <li class="nav-item dropdown">


        <a class="nav-link text-light ml-3 mr-1" href="#" data-toggle="dropdown" onclick="#">
        <?php echo e($categoria->nombre); ?>

        <span class="dropdown-toggle ml-1 mr-3" id="navbardrop" data-toggle="dropdown"></span>
        </a>



        <div class="dropdown-menu" style="background-color:#0362BC">
            <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item text-light" href="/Subcategoria/<?php echo e($subcategoria->slug); ?>"><?php echo e($subcategoria->nombre); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-light ml-3 mr-3" href="#" id="navbardrop" data-toggle="dropdown">
        Productos
        </a>
        <div class="dropdown-menu" style="background-color:#0362BC">
        <a class="dropdown-item text-light" href="#">Telares</a>
        <a class="dropdown-item text-light" href="#">Cartas de Colores</a>
        <a class="dropdown-item text-light" href="#">Catalogos</a>
        </div>
        </li>




        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-light ml-3 mr-3" href="#" id="navbardrop" data-toggle="dropdown">
        Contacto
        </a>
        <div class="dropdown-menu" style="background-color:#0362BC">
        <a class="dropdown-item text-light" href="#">Enviar Email</a>
        <a class="dropdown-item text-light" href="#">La Empresa</a>
        <a class="dropdown-item text-light" href="#">Ver Mapa</a>
        </div>
        </li>


        </ul>
    </div>
</nav>