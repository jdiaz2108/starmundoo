<div class="container-fluid mb-4 bg-white border shadow-sm">
    <div class="container">
        <div class="d-flex p-4">
          <div class="mr-auto h4 my-auto px-4">
          <a class="breadcrumb-item text-primary" href="/">Inicio</a>
          <?php if($link1->slug): ?>
                <a class="breadcrumb-item text-primary" href="<?php echo e($link1->slug); ?>" ><?php echo e(ucfirst(strtolower($link1->nombre))); ?></a>
           <?php endif; ?>
                <a class="breadcrumb-item active" aria-current="page"><?php echo e($link2->nombre); ?></a>
          </div>
        </div>
    </div>
</div>