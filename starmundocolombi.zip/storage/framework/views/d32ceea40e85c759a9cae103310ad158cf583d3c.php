<?php $__env->startSection('title', 'Categorias - '); ?>
<?php $__env->startSection('bc1link', 'mecago'); ?>
<?php $__env->startSection('bc1text', 'mecago1'); ?>

<?php $__env->startSection('bc2text', 'mecago2'); ?>

<?php $__env->startSection('content'); ?>
<?php
$categoria = App\Subcategoria::find($subcategoria->id)->categoria;
?>
<?php echo $__env->make('layouts.breadcrumb', ['link2' => $subcategoria, 'link1' => $categoria], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-6"> <img class="img-fluid d-block" src="https://static.pingendo.com/cover-bubble-light.svg"> </div>
        <div class="px-md-5 p-3 col-md-6 d-flex flex-column justify-content-center">
          <h1><?php echo e($subcategoria->nombre); ?></h1>
          <p class="mb-3 lead">Descripcion</p>
          <p class="mb-2">descrimpcion pequeña</p>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>