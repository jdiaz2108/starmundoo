@extends('layouts.base')

@section('title', 'Categorias - ')
@section('bc1link', 'mecago')
@section('bc1text', 'mecago1')

@section('bc2text', 'mecago2')

@section('content')
@php
$categoria = App\Subcategoria::find($subcategoria->id)->categoria;
@endphp
@include('layouts.breadcrumb', ['link2' => $subcategoria, 'link1' => $categoria])
<div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-6"> <img class="img-fluid d-block" src="https://static.pingendo.com/cover-bubble-light.svg"> </div>
        <div class="px-md-5 p-3 col-md-6 d-flex flex-column justify-content-center">
          <h1>{{ $subcategoria->nombre }}</h1>
          <p class="mb-3 lead">Descripcion</p>
          <p class="mb-2">descrimpcion pequeña</p>
        </div>
      </div>
    </div>
  </div>
@endsection