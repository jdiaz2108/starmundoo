<div class="container-fluid" style="background-color:#D2D5D3">
	<div class=	"row justify-content-md-center">
    	<div class="col-12 col-lg-3 text-center col-md-4">
        <img src="/imagenes/png/whatsapp-starmundocolombia.png" width="40" height="40" class="m-2" />
        <img src="/imagenes/png/correo.png" width="40" height="40" class="m-2" />
        <img src="/imagenes/png/mapa-starmundo.png" width="40" height="40" class="m-2" />
        </div>
        <div class="col-lg-3 col-md-1">
        </div>
        <div class="col-12 col-lg-4 text-center col-md-5">
        <img src="/imagenes/png/facebook-starmundo.png" width="40" height="40" class="m-2" />
              <a href="https://plus.google.com/u/0/117893975420182241931" target="_blank"><img src="/imagenes/png/googlemas-starmundo.png" width="40" height="40" border="0" class="m-2" /></a>
              <img src="/imagenes/png/instagram-starmundo.png" width="40" height="40" class="m-2" />
              <img src="/imagenes/png/youtube-starmundo.png" width="40" height="40" class="m-2" />
        </div>
    </div>
</div>