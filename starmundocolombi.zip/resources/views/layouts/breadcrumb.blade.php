<div class="container-fluid mb-4 bg-white border shadow-sm">
    <div class="container">
        <div class="d-flex p-4">
          <div class="mr-auto h4 my-auto px-4">
          <a class="breadcrumb-item text-primary" href="/">Inicio</a>
          @if($link1->slug)
                <a class="breadcrumb-item text-primary" href="{{$link1->slug}}" >{{ ucfirst(strtolower($link1->nombre))}}</a>
           @endif
                <a class="breadcrumb-item active" aria-current="page">{{$link2->nombre}}</a>
          </div>
        </div>
    </div>
</div>