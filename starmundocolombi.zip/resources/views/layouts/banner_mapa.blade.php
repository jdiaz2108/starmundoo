<div class="container-fluid"  style="background-color:#0362BC"><div class="container py-4">
<div class="row justify-content-center">


<div class="col-12 col-lg-5 col-md-10 p-3 pl-5 text-white">
<div class="text-center">
<img src="/imagenes/png/logo-starmundo.png" class="w-75 h-auto mt-2 mb-4" />
</div>


<div>
<img src="/imagenes/iconos/telefono-dientesysonrisa.png" width="20" height="25" class="my-2 mx-4" />355 676 5454
</div>

<div>
<img src="/imagenes/iconos/ubicacion-dientesysonrisa.png" width="20" height="25" class="my-2 mx-4" />Calle 19a No 72 - 65
</div>

<div>
<img src="/imagenes/iconos/ciudad-dientesysonrisa.png" width="20" height="25" class="my-2 mx-4" />Bogotá - Colombia
</div>

<div>
<img src="/imagenes/iconos/email-dientesysonrisa.png" width="20" height="25" class="my-2 mx-4" />correo@starmundocolombia.com
</div>

<div>
<img src="/imagenes/iconos/website-dientesusonrisa.png" width="20" height="25" class="my-2 mx-4" />www.starmundocolombia.com
</div>



</div>








<div class="col-12 col-lg-7 col-md-12 text-center">
<iframe src="https://www.google.com/maps/d/embed?mid=1HrfYniOA-p2oryDe3R-wia8WPvc61OAv" class="w-100" height="400px"></iframe>
</div>
</div>
</div>
</div>