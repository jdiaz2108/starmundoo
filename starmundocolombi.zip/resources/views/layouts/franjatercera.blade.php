<div class="container-fluid" style="background-image: url(/imagenes/jpg/fondohilos.jpg)">
<div class="row justify-content-center">
<div class="col-12 col-lg-10">
<div class="row justify-content-center stilo">
<h1 class="text-warning text-center mt-4 mb-2 mr-1">TELAS GÜTERMANN</h1>
</div>


<h4 class="text-light text-center m-4 stilo">
Representamos una de las más importantes marcas a nivel mundial en fabricación de hilos, 
estambres y demás productos relacionados
          </h4>
          
          
          <div class=" text-center m-4">
        <a href="nav.php?mod=Adornos" class="btn btn-light btn-lg" role="button" aria-pressed="true">Ver Mas</a>
        </div>
</div>
</div>
</div>